import React, { useState, useRef, useEffect } from 'react';
import { Send, Loader2, Dumbbell, Sparkles, Info } from 'lucide-react';
import { Message, Role } from './types';
import { sendMessageToGemini } from './services/gemini';
import { ChatMessage } from './components/ChatMessage';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: Role.MODEL,
      content: "### Benvenuto al ScienceBased Trainer\n\nSono un'intelligenza artificiale specializzata in **fisiologia dell'esercizio** e **biomeccanica**.\n\nPosso generare protocolli di allenamento ottimizzati basandomi sulle evidenze scientifiche più recenti (2020-2025).\n\n**Come posso aiutarti oggi?**\n- *Programmazione Ipertrofia (Stretch-mediated)*\n- *Ottimizzazione tecnica esecutiva*\n- *Analisi volume/intensità*",
      timestamp: Date.now(),
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [inputValue]);

  const handleSend = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userText = inputValue.trim();
    setInputValue('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
    setError(null);

    const newUserMessage: Message = {
      id: Date.now().toString(),
      role: Role.USER,
      content: userText,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, newUserMessage]);
    setIsLoading(true);

    try {
      const response = await sendMessageToGemini(messages, userText);
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: Role.MODEL,
        content: response.text,
        groundingMetadata: response.groundingMetadata,
        timestamp: Date.now(),
      };

      setMessages((prev) => [...prev, botMessage]);
    } catch (err) {
      console.error(err);
      setError("Si è verificato un errore di connessione. Riprova più tardi.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-screen font-sans overflow-hidden selection:bg-science-500/30">
      
      {/* Minimal Glass Header */}
      <header className="shrink-0 absolute top-0 w-full z-20 border-b border-white/5 bg-slate-950/60 backdrop-blur-xl py-4 px-6">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3 group cursor-default">
            <div className="relative">
              <div className="absolute inset-0 bg-science-500 blur-lg opacity-20 group-hover:opacity-40 transition-opacity duration-500 rounded-full"></div>
              <div className="relative bg-gradient-to-tr from-slate-800 to-slate-900 border border-slate-700 p-2 rounded-xl shadow-xl">
                <Dumbbell className="text-science-400 w-5 h-5" />
              </div>
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-100 tracking-tight leading-tight">
                ScienceBased Trainer
              </h1>
              <p className="text-[10px] text-slate-400 font-mono tracking-widest uppercase">Evidence-Based Protocol</p>
            </div>
          </div>
          <div className="hidden sm:block text-xs text-slate-500 border border-slate-800 bg-slate-900/50 px-3 py-1 rounded-full">
            v2.5 • Updated 2025
          </div>
        </div>
      </header>

      {/* Chat Area */}
      <main className="flex-1 overflow-y-auto pt-24 pb-6 px-4 md:px-6 scroll-smooth relative">
        <div className="max-w-3xl mx-auto space-y-8">
          {messages.map((msg) => (
            <ChatMessage key={msg.id} message={msg} />
          ))}
          
          {/* Loading State - Cyberpunk style */}
          {isLoading && (
            <div className="flex justify-start animate-fade-in pl-2">
               <div className="flex items-center gap-4">
                <div className="w-8 h-8 rounded-full bg-slate-800/80 border border-science-500/30 flex items-center justify-center shadow-[0_0_15px_rgba(14,165,233,0.15)]">
                  <Sparkles size={14} className="text-science-400 animate-pulse" />
                </div>
                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-2 text-xs font-mono text-science-400">
                    <Loader2 className="animate-spin" size={12} />
                    <span>ANALYZING_LITERATURE...</span>
                  </div>
                  <div className="h-1 w-24 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-science-500/50 animate-progress origin-left w-full"></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {error && (
            <div className="mx-auto max-w-md bg-red-500/10 border border-red-500/20 backdrop-blur-sm text-red-200 px-4 py-3 rounded-xl text-center text-sm shadow-lg">
              {error}
            </div>
          )}

          <div ref={messagesEndRef} className="h-4" />
        </div>
      </main>

      {/* Floating Input Area */}
      <footer className="shrink-0 p-4 md:p-6 z-20">
        <div className="max-w-3xl mx-auto relative">
          
          {/* Input Container */}
          <div className="relative flex items-end gap-2 bg-slate-900/80 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-1.5 shadow-2xl transition-all focus-within:border-science-500/50 focus-within:ring-1 focus-within:ring-science-500/20 group">
            
            <textarea
              ref={textareaRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Chiedi un programma di allenamento..."
              className="w-full bg-transparent text-slate-200 placeholder-slate-500 text-[15px] leading-relaxed px-4 py-3 focus:outline-none resize-none max-h-[120px] min-h-[52px] rounded-xl"
              rows={1}
            />
            
            <button
              onClick={handleSend}
              disabled={!inputValue.trim() || isLoading}
              className="mb-0.5 p-3 rounded-xl bg-gradient-to-br from-science-600 to-science-700 text-white hover:from-science-500 hover:to-science-600 disabled:from-slate-800 disabled:to-slate-800 disabled:text-slate-600 disabled:cursor-not-allowed transition-all duration-200 flex-shrink-0 shadow-lg shadow-science-900/20 active:scale-95 border border-white/10"
              aria-label="Invia"
            >
              {isLoading ? <Loader2 className="animate-spin w-5 h-5" /> : <Send className="w-5 h-5 ml-0.5" />}
            </button>
          </div>

          <div className="text-center mt-3 flex items-center justify-center gap-1.5 opacity-40 hover:opacity-70 transition-opacity duration-300">
             <Info size={10} className="text-slate-400" />
             <p className="text-[10px] text-slate-400 font-medium">
               AI generativa. Consulta un medico per idoneità fisica.
             </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;