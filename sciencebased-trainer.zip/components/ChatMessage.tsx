import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Message, Role } from '../types';
import { GroundingSources } from './GroundingSources';
import { Bot, User } from 'lucide-react';

interface ChatMessageProps {
  message: Message;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isBot = message.role === Role.MODEL;

  return (
    <div className={`flex w-full ${isBot ? 'justify-start' : 'justify-end'} group animate-slide-up`}>
      <div className={`flex max-w-[95%] md:max-w-[85%] lg:max-w-[80%] gap-4 ${isBot ? 'flex-row' : 'flex-row-reverse'}`}>
        
        {/* Avatar */}
        <div className={`shrink-0 w-9 h-9 rounded-xl flex items-center justify-center shadow-inner ${
          isBot 
            ? 'bg-slate-800/80 border border-science-500/20 text-science-400' 
            : 'bg-gradient-to-br from-emerald-500 to-emerald-700 text-white border border-white/10 shadow-lg shadow-emerald-900/20'
        }`}>
          {isBot ? <Bot size={18} /> : <User size={18} />}
        </div>

        {/* Message Bubble */}
        <div className={`flex flex-col w-full min-w-0`}>
          {/* Role Name (Optional, only for Bot for aesthetic) */}
          {isBot && (
            <span className="text-[10px] font-mono text-science-500/70 mb-1.5 ml-1 uppercase tracking-widest">
              AI Trainer Protocol
            </span>
          )}

          <div className={`relative px-6 py-5 shadow-md border backdrop-blur-md ${
            isBot 
              ? 'bg-slate-900/60 border-slate-700/60 text-slate-200 rounded-2xl rounded-tl-sm' 
              : 'bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700 text-slate-100 rounded-2xl rounded-tr-sm'
          }`}>
            <div className="prose prose-invert prose-sm max-w-none break-words prose-p:leading-relaxed prose-headings:font-semibold prose-headings:tracking-tight">
              <ReactMarkdown 
                remarkPlugins={[remarkGfm]}
                components={{
                  // Tables: Scientific Look
                  table: ({node, ...props}) => (
                    <div className="overflow-hidden my-6 border border-slate-700/60 rounded-xl bg-slate-900/40 shadow-sm">
                      <table className="min-w-full divide-y divide-slate-700/60" {...props} />
                    </div>
                  ),
                  thead: ({node, ...props}) => <thead className="bg-slate-800/60" {...props} />,
                  th: ({node, ...props}) => <th className="px-4 py-3 text-left text-[10px] font-mono uppercase tracking-wider font-bold text-science-400" {...props} />,
                  td: ({node, ...props}) => <td className="px-4 py-3 whitespace-normal text-xs md:text-sm border-t border-slate-700/30 text-slate-300" {...props} />,
                  tr: ({node, ...props}) => <tr className="hover:bg-white/5 transition-colors" {...props} />,
                  
                  // Lists
                  ul: ({node, ...props}) => <ul className="list-none ml-0 space-y-2 my-4" {...props} />,
                  li: ({node, children, ...props}) => (
                    <li className="flex gap-3 items-start" {...props}>
                      <span className="mt-2 w-1.5 h-1.5 rounded-full bg-science-500/50 shrink-0" />
                      <span>{children}</span>
                    </li>
                  ),
                  ol: ({node, ...props}) => <ol className="list-decimal list-outside ml-5 space-y-2 my-4 marker:text-science-500/70 marker:font-mono marker:text-xs" {...props} />,
                  
                  // Headings
                  h1: ({node, ...props}) => <h1 className="text-xl font-bold mb-4 text-white" {...props} />,
                  h2: ({node, ...props}) => <h2 className="text-lg font-bold mt-6 mb-3 text-science-50 border-b border-slate-700/50 pb-2" {...props} />,
                  h3: ({node, ...props}) => <h3 className="text-base font-semibold mt-5 mb-2 text-science-300" {...props} />,
                  
                  // Emphasis
                  strong: ({node, ...props}) => <strong className="font-bold text-science-200 bg-science-500/10 px-1 rounded" {...props} />,
                  a: ({node, ...props}) => <a className="text-science-400 hover:text-science-300 underline decoration-science-500/30 hover:decoration-science-500 transition-all" target="_blank" rel="noreferrer" {...props} />,
                  blockquote: ({node, ...props}) => <blockquote className="border-l-4 border-science-600 pl-4 py-1 my-4 bg-slate-800/30 rounded-r-lg italic text-slate-400" {...props} />,
                  code: ({node, ...props}) => <code className="font-mono text-xs bg-slate-950 px-1.5 py-0.5 rounded text-science-300 border border-slate-800" {...props} />,
                }}
              >
                {message.content}
              </ReactMarkdown>
            </div>
            
            {/* Grounding Sources (Only for Bot) */}
            {isBot && message.groundingMetadata && (
              <GroundingSources metadata={message.groundingMetadata} />
            )}
          </div>
          
          {/* Timestamp */}
          <div className={`text-[10px] mt-1.5 text-slate-500 font-mono opacity-0 group-hover:opacity-100 transition-opacity duration-300 ${isBot ? 'text-left ml-1' : 'text-right mr-1'}`}>
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
        </div>
      </div>
    </div>
  );
};