import React from 'react';
import { GroundingMetadata } from '../types';
import { Link, BookOpen } from 'lucide-react';

interface GroundingSourcesProps {
  metadata: GroundingMetadata | null | undefined;
}

export const GroundingSources: React.FC<GroundingSourcesProps> = ({ metadata }) => {
  if (!metadata || !metadata.groundingChunks || metadata.groundingChunks.length === 0) {
    return null;
  }

  const validSources = metadata.groundingChunks.filter(
    (chunk) => chunk.web?.uri && chunk.web?.title
  );

  if (validSources.length === 0) return null;

  return (
    <div className="mt-5 pt-4 border-t border-dashed border-slate-700/50">
      <div className="flex items-center gap-2 text-[10px] font-mono text-science-400/80 mb-3 uppercase tracking-wider">
        <BookOpen size={12} />
        Riferimenti & Citazioni
      </div>
      <div className="flex flex-wrap gap-2">
        {validSources.map((source, index) => (
          <a
            key={index}
            href={source.web?.uri}
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-center gap-2 px-3 py-1.5 bg-slate-900/50 hover:bg-science-900/20 border border-slate-700/70 hover:border-science-500/40 rounded-lg transition-all duration-200 max-w-full"
          >
            <div className="bg-slate-800 group-hover:bg-science-800/50 p-1 rounded text-slate-400 group-hover:text-science-200 transition-colors">
                <Link size={10} />
            </div>
            <span className="truncate max-w-[180px] text-xs text-slate-300 group-hover:text-science-100 font-medium">
                {source.web?.title}
            </span>
          </a>
        ))}
      </div>
    </div>
  );
};